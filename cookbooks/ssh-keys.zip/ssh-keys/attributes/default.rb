default['ssh_keys_keep_existing'] = true
default['ssh_keys_skip_missing_home'] = false
default['ssh_keys_create_missing_home'] = false
default['ssh_keys_use_encrypted_data_bag'] = false
